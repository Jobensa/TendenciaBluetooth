#ifndef _USER_BLUETOOT_H_
#define _USER_BLUETOOT_H

#include "user.h"

void Task_bluetooth(void* parameter);


#endif